package com.dynious.refinedrelocation.api.tileentity;

import com.dynious.refinedrelocation.api.filter.IFilter;

public interface IFilterTile
{
    public IFilter getFilter();
}
