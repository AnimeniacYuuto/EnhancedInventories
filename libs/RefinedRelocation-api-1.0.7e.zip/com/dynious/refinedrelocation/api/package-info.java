@API(apiVersion = "1.0.0", owner = "RefinedRelocation", provides = "RefinedRelocationAPI") package com.dynious.refinedrelocation.api;

import cpw.mods.fml.common.API;
