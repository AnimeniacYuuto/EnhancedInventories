package com.dynious.refinedrelocation.api.tileentity;

public interface IInventoryChangeListener
{
    public void onInventoryChanged();
}
